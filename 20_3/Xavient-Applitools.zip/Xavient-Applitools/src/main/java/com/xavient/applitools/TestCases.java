package com.xavient.applitools;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.Eyes;
import com.applitools.eyes.RectangleSize;

public class TestCases {

	public static String ApplitolsApiKey = "rC1u1jCnDx78XDc598c100PSKeDgtDbOLdOLfiKFUWq5108k110";
	public static WebDriver driver;
	public static Eyes eyes = null;
	public static BatchInfo batchinfo;
	
	@BeforeTest
	public void atSetup(){
		
		System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir")+"\\BrowserDriver\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		eyes = new Eyes();
		eyes.setApiKey(ApplitolsApiKey);
		eyes.setForceFullPageScreenshot(true);
		driver.get("https://www.hallwaze.com/");
		driver = eyes.open(driver, "APP", "Hallwaze Demo", new RectangleSize(900, 700));
	}
	
	
	@Test
	public void testcase() throws Exception{
		
		Thread.sleep(10000);
		eyes.checkWindow();
		driver.findElement(By.linkText("Product")).click();
		Thread.sleep(10000);
		eyes.checkWindow();
		
		
	}
	
	@AfterTest
	public void tearDown(){
		
		driver.quit();
   		eyes.abortIfNotClosed();
	}
}
