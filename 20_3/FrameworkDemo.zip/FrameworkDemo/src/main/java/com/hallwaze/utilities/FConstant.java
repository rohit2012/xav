package com.hallwaze.utilities;

public interface FConstant {

	String ChromeDriverPath = "\\src\\main\\resources\\BrowserDriver\\" + "chromedriver.exe";
	String IEDriverPath = "\\src\\main\\resources\\BrowserDriver\\" + "IEDriverServer.exe";
	String FirefoxDriverPath = "\\src\\main\\resources\\BrowserDriver\\" + "geckodriver.exe";
	
	String ScreenShotPath = "screenshot";
}
