Jenkins v2.60.1 standalone Setup !!

Step 1:- Create Folder structure :- /var/volume/jenkins/

Step 2:- Clone this repository on to a local machine

Step 3:- docker-compose up -d 


Jenkins version no 2.60.1 exposed on port 8080 with Volume /var/volume/jenkins/.


Some basic commands for docker-compose :-

Start

$ sudo docker-compose -f <compose-file> up -d

Stop

$ sudo docker-compose -f <compose-file> stop

Restart

$ sudo docker-compose -f <compose-file> restart

Status

$ sudo docker-compose -f <compose-file> ps

Logs

$ sudo docker-compose -f <compose-file> logs

Remove

$ sudo docker-compose -f <compose-file> rm

NOTE: On OSX, you should omit the sudo from all your docker-compose commands
